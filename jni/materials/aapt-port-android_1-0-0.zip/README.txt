AAPT port to Android 1.0.0
==========================

This is a port of AAPT to Android
(Android >=2.3, arm)

Creating an aapt console application for Android
================================================
1. Download and install the latest Android NDK
2. Download and install Cygwin
3. Start Cygwin
4. Get GNUMAKE
5. Run JavaIDEdroid/ndk-build-aaptcomplete.sh
-> aaptcomplete will be created in JavaIDEdroid/libs/armeabi/


Creating the libaaptcomplete.so
===============================
To create a shared library you will need to modify JavaIDEdroid/jni/Android.mk:
- deactivate "include $(BUILD_EXECUTABLE)"
- activate "include $(BUILD_SHARED_LIBRARY)"
-> libaaptcomplete.so will be created in JavaIDEdroid/libs/armeabi/

Before you can use this shared library from an Android Java app,
you will need to add the JNI interface and to return the output
of stdout and stderr through the JNI interface.

License
=======
This port is distributed under the GPLv2

Tom Arn, www.t-arn.com, 2011-08-16
