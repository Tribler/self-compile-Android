#!/bin/sh
# 
export NDK_PROJECT_PATH=.
/cygdrive/u/Programs/android-ndk/ndk-build
